## Example Solutions ##

#1
ip <- function(n=1){
  ip_1 = sample.int(255, n, replace = TRUE)
  ip_2 = sample.int(256, n, replace = TRUE) - 1
  ip_3 = sample.int(256, n, replace = TRUE) - 1
  ip_4 = sample.int(256, n, replace = TRUE) - 1
   return(paste(ip_1, ip_2, ip_3, ip_4, sep ='.'))
}


#2
date <- function(start_date="01/01/2020", end_date="01/12/2020", n=1){
  start_date = as.POSIXlt(0, origin = paste(start_date," 00:00"), tz= "UCT", format = "%d/%m/%Y %H:%M")
  end_date = as.POSIXlt(0, origin = paste(end_date," 00:00"), tz= "UCT", format = "%d/%m/%Y %H:%M")
  #end_date = as.POSIXlt(60, origin = paste(end_date," 23:59"), tz= "UCT", format = "%d/%m/%Y %H:%M")
  interval_mins = as.integer(end_date - start_date)*24*60
  sample_hrs = sample.int(interval_mins, n)
  dates = as.POSIXlt(sample_hrs*60, origin = "01/01/2020 00:00", tz= "UCT", format = "%d/%m/%Y %H:%M")
  return(format(dates, "%Y-%m-%d %H:%M"))
}


#3
response <- c("1-Very Unhappy","2-Unhappy", "3-Content", "4-Happy", "5-Very Happy", NA)
prob <- c(0.16, 0.16, 0.16, 0.16, 0.16, 0.2)
survey_vec <- sample(response, 100000, replace = TRUE, prob = prob)


#4
ip_sample = ip(10000)
date_sample = date(n=10000)
na_sampler = function(x){
  # Takes a string checks if x is NA, and returns random of ip, date, or NA if so; returns x otherwise.
  ip_random = sample(ip_sample, 1)
  date_random = sample(date_sample, 1)
  random = sample(c(ip_random, date_random, NA), 1, prob=c(0.4, 0.4, 0.2))
  return(ifelse(is.na(x), random, x))
  }
data = purrr::map_chr(survey_vec, na_sampler) # sapply but better
#sum(grepl('.', data, fixed = TRUE)) check #of ip's
#sum(grepl(':', data, fixed = TRUE)) check #of date's
survey_df = as.data.frame(matrix(data, ncol=10, byrow=TRUE))


#5
df <- readr::read_csv("~/Desktop/UofT/dev/R_beginner_exercise/survey_df.csv")
n_ip = sum(grepl('.', df$V1, fixed = TRUE))
n_date = sum(grepl(':', df$V1, fixed = TRUE))
ip_gone = head(sub('.', NA, df$V1, fixed = TRUE),20)
x = sub(':', NA, ip_gone, fixed = TRUE)
x_num = as.numeric(sub("-.*", "", x))


#6
clear_cols = function(df_col){
  df_col = sub('.', NA, df_col, fixed = TRUE)
  df_col = sub(':', NA, df_col, fixed = TRUE)
  return(as.numeric(sub("-.*", "", df_col)))
}
df = as.data.frame(sapply(df, clear_cols))
head(df)

#7
library(gapminder)
library(tidyverse)
df_gap = gapminder

#7.1
#df_gap %>% mutate(has_a = grepl('a',country))%>%group_by(has_a)%>%summarise(x=n())
average_life_df = df_gap %>% group_by(continent) %>% 
  summarise(average_exp = mean(lifeExp), n_countries = n()) %>%
  arrange(desc(average_exp))


