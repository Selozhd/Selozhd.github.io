# Paths
IMAGES_DIR = 'images'
DATA_DIR = 'data'

# Plotting
PLOTTING_STYLE = ['science', 'ieee']
