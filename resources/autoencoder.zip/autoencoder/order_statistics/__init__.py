"""Mocked import of OrderStats library."""

import sys as _sys

_sys.path.append('../order_statistics/')

from orderstats import distributions
from orderstats import plot_utils
from orderstats import scoring
from orderstats import tail_estimation
from orderstats import utils

__all__ = [
    'distributions', 'plot_utils', 'scoring', 'tail_estimatione', 'utils'
]
