"""Experiments and examples from the library."""

import datetime
import functools

import numpy as np
import tensorflow as tf
from tensorflow.keras import layers

from constants import DATA_DIR
from order_statistics import distributions
from order_statistics import utils as stat_utils
from outliers.autoencoder import *
from outliers.classification_utils import get_classification_report
from outliers.cumulative_anomaly import *
from outliers.data_reader import *
from outliers.multigan_anomaly import *
from outliers.orderstats_anomaly import *
from outliers.plotting import *
from outliers.preprocesor import *
from outliers.training import AlgorithmType, TrainConfig, Trainer, Evaluator


def get_experiment_name(model, data):
    time = datetime.datetime.now().strftime("%b%d-%H%M")
    return '_'.join((model, data, time))


def normalize_image(x):
    return np.asarray(x, np.float32)/256.0


def get_mnist_model():
    model = tf.keras.Sequential([
        layers.Dense(256),
        layers.Dense(32),
        layers.Dense(256),
        layers.Dense(784),
    ])
    return model


def get_abu_model(dim):
    model = tf.keras.Sequential([
        layers.Dense(100),
        layers.Dense(50),
        layers.Dense(25),
        layers.Dense(50),
        layers.Dense(100),
        layers.Dense(dim),
    ])
    return model


def train_mnist(mnist_data, train_cfg):
    experiment_name = get_experiment_name(model=train_cfg.model.name,
                                          data="MNIST")
    trainer = Trainer(experiment_name, train_cfg.to_dict(), train_cfg.seed)
    trainer.create_training_data(mnist_data, sampler=train_cfg.sampler)
    trainer.preprocess(cts_transforms=train_cfg.cts_transforms,
                       cat_transforms=train_cfg.cat_transforms)
    trainer.build_model(autoencoder=train_cfg.autoencoder,
                        model=train_cfg.model.get(),
                        model_kwargs=train_cfg.model_kwargs,
                        metrics=train_cfg.metrics,
                        optimizer=train_cfg.optimizer,
                        loss=train_cfg.loss)
    trainer.train(batch_size=train_cfg.batch_size,
                  epochs=train_cfg.epochs,
                  callbacks=train_cfg.callbacks,
                  validation_data=(trainer.X, trainer.y))
    trainer.evaluate()
    trainer.save()
    return trainer


def train_uci(dataset_name, train_cfg):
    experiment_name = get_experiment_name(model=train_cfg.model.name,
                                          data="UCI")
    trainer = Trainer(experiment_name, train_cfg.to_dict(), train_cfg.seed)
    trainer.create_training_data(dataset_name, sampler=train_cfg.sampler)
    trainer.preprocess(cts_transforms=train_cfg.cts_transforms,
                       cat_transforms=train_cfg.cat_transforms)
    trainer.build_model(autoencoder=train_cfg.autoencoder(trainer.X.shape[-1]),
                        model=train_cfg.model.get(),
                        model_kwargs=train_cfg.model_kwargs,
                        metrics=train_cfg.metrics,
                        optimizer=train_cfg.optimizer,
                        loss=train_cfg.loss)
    trainer.train(batch_size=train_cfg.batch_size,
                  epochs=train_cfg.epochs,
                  callbacks=train_cfg.callbacks,
                  validation_data=(trainer.X, trainer.y))
    trainer.evaluate()
    trainer.save()
    return trainer


if True and __name__ == '__main__':
    ##  MNIST Pipeline
    sampler = sample_with_anomalies(2, 4, percentage=0.02)
    func = ApplyFunction(normalize_image)
    kappa_stop = KappaThresholdStopping()
    cts = [func]
    cat = []

    trainer_config = TrainConfig(
        model=AlgorithmType.OrderStats,
        model_kwargs={'loss_weights': True},
        autoencoder=get_mnist_model(),
        sampler=sampler,
        seed=42,
        cts_transforms=cts,
        cat_transforms=cat,
        loss=tf.losses.MSE,
        optimizer=tf.optimizers.Adam(learning_rate=1e-3),
        metrics=[tf.metrics.AUC(), tf.metrics.Precision()],
        callbacks=[kappa_stop],
        batch_size=2991,
        epochs=200,
    )
    trainer = train_mnist('digits', trainer_config)
    evaluator = Evaluator(trainer.name)
    #report = evaluator.eval(*trainer.data_reader.load_test(), save_data=True)

if False and __name__ == '__main__':
    ## CumulativeAnomaly Pipeline
    sampler = sample_with_anomalies(2, 'all', percentage=0.02)
    knee_stopping = KneeStopping()

    train_config = TrainConfig(
        model=AlgorithmType.Cumulative,
        model_kwargs={'alpha': 2},
        autoencoder=get_mnist_model(),
        sampler=sampler,
        seed=42,
        cts_transforms=[ApplyFunction(normalize_image)],
        cat_transforms=[],
        loss=PercentileLoss(tf.losses.MSE, percentile=.98),
        optimizer=tf.optimizers.Adam(learning_rate=1e-3),
        metrics=[tf.metrics.AUC(), tf.metrics.Precision()],
        callbacks=[knee_stopping],
        batch_size=2991,
        epochs=100,
    )
    trainer = train_mnist('digits', train_config)

if False and __name__ == '__main__':
    ## UCI Dataset Pipeline
    kappa_stop = KappaThresholdStopping()

    trainer_config = TrainConfig(
        model=AlgorithmType.OrderStats,
        model_kwargs={'loss_weights': True},
        autoencoder=lambda x: get_autoencoder(
            [x, 18, 15]),  # Called with trainer.X.shape[-1]
        sampler=None,
        seed=42,
        cts_transforms=[],
        cat_transforms=[],
        loss=tf.losses.MSE,
        optimizer=tf.optimizers.Adam(learning_rate=1e-4),
        metrics=[tf.metrics.AUC(), tf.metrics.Precision()],
        callbacks=[],
        batch_size=128,
        epochs=200,
    )
    trainer = train_uci('annthyroid', trainer_config)
    evaluator = Evaluator(trainer.name)
    report = evaluator.eval(*trainer.data_reader.load_test(), save_data=True)