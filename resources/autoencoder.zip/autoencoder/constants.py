# Paths
DATA_DIR = 'data/'
IMAGES_DIR = 'images/'
EXPERIMENTS_DIR = 'experiments/'

# Plotting
PLOTTING_STYLE = ['default']